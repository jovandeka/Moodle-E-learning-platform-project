function funkcija = ez_povrsina(x)

funkcija = 50*x(1)^2+x(2)^4-50-x(2)^2;

end